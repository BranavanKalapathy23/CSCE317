# Interrupt timer demonstration

This demonstration shows the usage of the interrupt timer to implement a simple
LED blink program.
